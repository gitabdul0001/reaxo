export type Theme = 'light' | 'dark';
export type Container = 'centered' | 'none';
